from __future__ import annotations

from typing import List, Sequence

from .base import SensorAdapter, SensorObservation, SensorStatus
from .camera import CameraUnavailableError, OpenCVCameraAdapter
from .microphone import MicrophoneUnavailableError, SoundDeviceMicrophoneAdapter
from ..config import WonderBotConfig


class SensorHub:
    def __init__(self, adapters: Sequence[SensorAdapter] | None = None, statuses: Sequence[SensorStatus] | None = None) -> None:
        self.adapters = list(adapters or [])
        self._statuses = list(statuses or [])

    def poll(self) -> List[SensorObservation]:
        observations: List[SensorObservation] = []
        updated_statuses: List[SensorStatus] = []
        for adapter in self.adapters:
            try:
                observations.extend(adapter.poll())
                updated_statuses.append(adapter.status())
            except Exception as exc:
                updated_statuses.append(SensorStatus(source=adapter.name, enabled=True, available=False, detail=str(exc)))
        if updated_statuses:
            self._statuses = updated_statuses
        return observations

    def status(self) -> List[SensorStatus]:
        if self._statuses:
            return list(self._statuses)
        return [adapter.status() for adapter in self.adapters]

    def close(self) -> None:
        for adapter in self.adapters:
            try:
                adapter.close()
            except Exception:
                pass



def build_sensor_hub(config: WonderBotConfig) -> SensorHub:
    adapters: List[SensorAdapter] = []
    statuses: List[SensorStatus] = []

    if config.camera.enabled:
        try:
            adapters.append(
                OpenCVCameraAdapter(
                    index=config.camera.index,
                    width=config.camera.width,
                    height=config.camera.height,
                    motion_threshold=config.camera.motion_threshold,
                    brightness_threshold=config.camera.brightness_threshold,
                    min_salience=config.camera.min_salience,
                )
            )
            statuses.append(SensorStatus(source="camera", enabled=True, available=True, detail="camera adapter active"))
        except CameraUnavailableError as exc:
            statuses.append(SensorStatus(source="camera", enabled=True, available=False, detail=str(exc)))
    else:
        statuses.append(SensorStatus(source="camera", enabled=False, available=False, detail="camera disabled in config"))

    if config.microphone.enabled:
        try:
            adapters.append(
                SoundDeviceMicrophoneAdapter(
                    sample_rate=config.microphone.sample_rate,
                    channels=config.microphone.channels,
                    window_seconds=config.microphone.window_seconds,
                    rms_threshold=config.microphone.rms_threshold,
                    peak_threshold=config.microphone.peak_threshold,
                    min_salience=config.microphone.min_salience,
                )
            )
            statuses.append(SensorStatus(source="microphone", enabled=True, available=True, detail="microphone adapter active"))
        except MicrophoneUnavailableError as exc:
            statuses.append(SensorStatus(source="microphone", enabled=True, available=False, detail=str(exc)))
    else:
        statuses.append(SensorStatus(source="microphone", enabled=False, available=False, detail="microphone disabled in config"))

    return SensorHub(adapters=adapters, statuses=statuses)
